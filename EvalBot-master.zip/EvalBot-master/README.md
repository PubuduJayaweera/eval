# EvalBot
* Clone repo to anywhere and rename settings.js_example to settings.js
* configure settings.js as explained in the file
* Make sure you have nodejs 6.6.0 installed
* cd to the bots directory  in your command line
* run `npm install`
* run `npm install forever -g`
* run `forever bot.js`
* ???
* profit
